import React from "react";
import { Link } from "react-router-dom";
let Navbar = () => {
  return (
    <React.Fragment>
      <nav className="navbar navbar-dark bg-dark navbar-expand-sm">
        <div className="container">
          <Link to="" className="navbar-brand">
            EUC Excel Analyzer
          </Link>
          <div className="collapase navbar-collapse">
            <ul className="navbar-nav">
              <li className="nav-item px-2">
                <Link to="/home" className="nav-link">
                  Home
                </Link>
              </li>
              <li className="nav-item px-2">
                <Link to="/login" className="nav-link">
                  Login
                </Link>
              </li>
              <li className="nav-item px-2">
                <Link to="/register" className="nav-link">
                  Register
                </Link>
              </li>
              <li className="nav-item px-2">
                <Link to="/employe" className="nav-link">
                  Employee Info
                </Link>
              </li>
              <li className="nav-item px-2">
                <Link to="/emputil" className="nav-link">
                  Employee Utilization
                </Link>
              </li>
            </ul>
          </div>
          <select className="form-select" aria-label="Default select example">
            <option selected>Technologies</option>
            <option value="1">SpringBoot</option>
            <option value="2">JS</option>
            <option value="3">React Js</option>
          </select>
        </div>
      </nav>
    </React.Fragment>
  );
};

export default Navbar;
