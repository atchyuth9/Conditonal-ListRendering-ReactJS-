import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./styles.css";
import Register from "./Components/Register";
import Home from "./Components/Home";
import Login from "./Components/Login";
import Employe from "./Components/Employe";
import Employeutilization from "./Components/Employeutilization";
import Navbar from "./Components/Navbar.js";
import vir from "./vir.jpeg";
function App() {
  return (
    <React.Fragment>
      <div className="App">
        <Router>
          <Navbar />
          <Routes>
            <Route exact path="/home" element={<Home />} />
            <Route exact path="/login" element={<Login />} />
            <Route exact path="/register" element={<Register />} />
            <Route exact path="/employe" element={<Employe />} />
            <Route exact path="/emputil" element={<Employeutilization />} />
          </Routes>
        </Router>
      </div>
    </React.Fragment>
  );
}
export default App;
