import React from "react";

let Home = () => {
  return (
    <React.Fragment>
      <div className="landing-page">
        <div className="wrapper">
          <div className="d-flex flex-column justify-content-center text-center align-items-center h-100">
            <h2 className="display-3">Welcome </h2>
            <p className="p">
              Virtusa Corporation is an American information technology services
              company founded in 1996 in Sri Lanka and has its headquarters in
              Southborough, Massachusetts, United States.
            </p>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Home;
