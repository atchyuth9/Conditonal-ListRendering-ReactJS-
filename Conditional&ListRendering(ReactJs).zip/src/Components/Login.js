import React, { useState } from "react";

let Login = () => {
  let [log, setLog] = useState({
    login: {
      email: "",
      password: ""
    }
  });
  let sub = (e) => {
    e.preventDefault();
    console.log(log.login);
  };
  let logs = (e) => {
    setLog({
      login: { ...log.login, [e.target.name]: e.target.value }
    });
  };
  return (
    <React.Fragment>
      <center>
        <form onSubmit={sub}>
          <label>
            <h2>Enter Login Details</h2>
          </label>
          <br />
          <input
            onChange={logs}
            type="email"
            name="email"
            placeholder="Enter Your Mail Id"
          />
          <br />
          <input
            onChange={logs}
            type="password"
            name="password"
            placeholder="Enter Password"
          />
          <br />
          <label>
            <input type="submit" value="Register" />
          </label>
          <input type="submit" value="Login" />
        </form>
      </center>
    </React.Fragment>
  );
};
export default Login;
