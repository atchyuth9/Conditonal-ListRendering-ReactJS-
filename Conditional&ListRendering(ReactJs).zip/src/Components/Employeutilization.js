import React, { useState } from "react";
let Employeutilization = () => {
  let [util, setUtil] = useState({
    Employee: "Atchyuth Brundavanam [8093696]",
    ProjectName: "FxLM OPS Tech ehancements",
    ProjectNumber: "21994",
    Role: "Software Engineer",
    StartDate: "18-Aug-2021",
    EndDate: "31-Dec-2022",
    LastWorkingDate: "No Last Working Date",
    ATC: "PCS CHE",
    ProjectType: "Direct",
    ProjectSBU: "AMER BFS CITI MSST"
  });
  let {
    Employee,
    ProjectName,
    ProjectNumber,
    Role,
    StartDate,
    EndDate,
    LastWorkingDate,
    ATC,
    ProjectType,
    ProjectSBU
  } = util;

  return (
    <React.Fragment>
      {/*<pre>{JSON.stringify(util)}</pre>*/}
      <h3>Employee Utilization</h3>
      <table
        id="dtHorizontalExample"
        class="table table-striped table-bordered table-sm"
        cellspacing="0"
        width="100%"
      >
        <thead>
          <tr>
            <th>Employee</th>
            <th>ProjectName</th>
            <th>ProjectNumber</th>
            <th>Role</th>
            <th>StartDate</th>
            <th>End date</th>
            <th>LastWorkingDate</th>
            <th>ATC</th>
            <th>ProjectType</th>
            <th>ProjectSBU</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{util.Employee}</td>
            <td>{util.ProjectName}</td>
            <td>{util.ProjectNumber}</td>
            <td>{util.Role}</td>
            <td>{util.StartDate}</td>
            <td>{util.EndDate}</td>
            <td>{util.LastWorkingDate}</td>
            <td>{util.ATC}</td>
            <td>{util.ProjectType}</td>
            <td>{util.ProjectSBU}</td>
          </tr>
        </tbody>
      </table>
    </React.Fragment>
  );
};

export default Employeutilization;
