import React, { useState } from "react";

let Register = () => {
  let [user, setUser] = useState({
    register: {
      username: "",
      password: "",
      email: "",
      terms: "false"
    }
  });
  let regi = (e) => {
    setUser({
      register: {
        ...user.register,
        [e.target.name]: e.target.value
      }
    });
  };
  let submit = (e) => {
    e.preventDefault();
    console.log(user.register);
  };
  let checkbox = (e) => {
    setUser({
      register: {
        ...user.register,
        [e.target.name]: e.target.checked
      }
    });
  };
  return (
    <React.Fragment>
      {/*<pre>{JSON.stringify(user)}</pre>*/}
      <div className="form">
        <form onSubmit={submit}>
          <input
            onChange={regi}
            type="text"
            name="username"
            placeholder="Enter User Name"
          />
          <br />
          <input
            onChange={regi}
            type="password"
            name="password"
            placeholder="Enter Password"
          />
          <br />
          <input
            onChange={regi}
            type="email"
            name="email"
            placeholder="Enter Mail"
          />
          <br />
          <input
            onChange={checkbox}
            type="checkbox"
            id="defaultcheck"
            name="terms"
          />
          <label> Accept Terms & Conditions</label>
          <br />
          <input type="submit" value="submit" />
        </form>
      </div>
    </React.Fragment>
  );
};

export default Register;
